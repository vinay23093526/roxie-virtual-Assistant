import pyautogui

pyautogui.press('super')
pyautogui.typewrite("chrome")
pyautogui.sleep(0.7)
pyautogui.press("enter")